package corejava;

public class JavaSample {

}
